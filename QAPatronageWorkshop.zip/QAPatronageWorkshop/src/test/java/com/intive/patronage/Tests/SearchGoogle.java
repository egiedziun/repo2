package com.intive.patronage.Tests;
import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Created by EiM on 2018-01-11.
 */
public class SearchGoogle {

	//constructor
    public SearchGoogle() {
        System.out.println("We are inside constructor SearchGoogle class");
    }
    
    @Test
    public void myFirstAction() throws InterruptedException {
        System.setProperty("webdriver.gecko.driver","geckodriver.exe");
        WebDriver driver = new FirefoxDriver();

        driver.get("http://google.com");
        Thread.sleep (3000);
        driver.quit();

    }
    @Test
    public void google_Search()
    {
        System.setProperty("webdriver.gecko.driver","geckodriver.exe");
    	
    	String expectedlink = "https://www.intive.com/en";
    			
    			//load firefox and run with google.com site
    			WebDriver driver;
    	driver = new FirefoxDriver();
    	driver.get("http://www.google.com");
    	
    	//submit string in search field
    	WebElement element = driver.findElement(By.name("q"));
    	element.sendKeys("intive\n");
    	element.submit();
    	
    	//Wait until the google page shows the result
    	WebElement myDynamicElement = (new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("resultStats")));
    	
    	//store google results
    	List<WebElement> findElements = driver.findElements(By.xpath("//*[@id='rso']//h3/a"));
    	
    	//Get the url of first link
    	String first_link = findElements.get(0).getAttribute("href");
    	
    	//check of first link ist correct link
    	assertEquals(first_link, expectedlink);
    	
    	driver.quit();
    }
}

