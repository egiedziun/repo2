package com.intive.patronage;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.intive.patronage.Tests.SearchGoogle;

@RunWith(Suite.class)
@Suite.SuiteClasses({SearchGoogle.class})
//ta klasa musi wiedziec co musi uruchomic

public class TestRunner
{
	
}
